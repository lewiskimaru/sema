import { ReactNode, useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';

interface SidebarItemProps {
  icon: ReactNode;
  title: string;
  to?: string;
  onClick?: () => void;
  isActive?: boolean;
  isNew?: boolean;
  extensionContent?: ReactNode;
}

export default function SidebarItem({
  icon,
  title,
  to,
  onClick,
  isActive = false,
  isNew = false,
  extensionContent
}: SidebarItemProps) {
  const [showExtension, setShowExtension] = useState(false);
  const extensionTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const itemRef = useRef<HTMLDivElement>(null);
  
  const handleMouseEnter = () => {
    if (extensionTimeoutRef.current) {
      clearTimeout(extensionTimeoutRef.current);
      extensionTimeoutRef.current = null;
    }
    
    if (extensionContent) {
      setShowExtension(true);
    }
  };
  
  const handleMouseLeave = () => {
    if (extensionContent) {
      extensionTimeoutRef.current = setTimeout(() => {
        setShowExtension(false);
      }, 300); // Slight delay before hiding extension
    }
  };
  
  useEffect(() => {
    return () => {
      if (extensionTimeoutRef.current) {
        clearTimeout(extensionTimeoutRef.current);
      }
    };
  }, []);
  
  const itemContent = (
    <div 
      className={`relative flex flex-col items-center justify-center p-1 transition-all duration-200 ${
        isActive ? 'text-black' : 'text-[#555555] hover:text-black'
      }`}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      ref={itemRef}
    >
      <div className={`p-2 ${
        isNew 
          ? 'bg-black text-white rounded-full' 
          : isActive 
            ? 'bg-[#EAEAEA] rounded-lg' 
            : 'hover:bg-[#EAEAEA] rounded-lg'
      }`}>
        {icon}
      </div>
      <span className="text-xs mt-1">{title}</span>
      
      {/* Extension that appears on hover */}
      {extensionContent && showExtension && (
        <div 
          className="absolute left-full ml-2 w-56 bg-[#F0F0F0] rounded-lg shadow-sm border border-[#EFEFEF] z-50 origin-left"
          style={{
            top: '0',
            animation: 'sidebar-extension-in 0.2s ease-out forwards'
          }}
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
        >
          {extensionContent}
        </div>
      )}
    </div>
  );
  
  if (to) {
    return (
      <Link to={to} className="no-underline">
        {itemContent}
      </Link>
    );
  }
  
  return (
    <button 
      onClick={onClick} 
      className="bg-transparent border-0 cursor-pointer w-full text-inherit"
    >
      {itemContent}
    </button>
  );
}
