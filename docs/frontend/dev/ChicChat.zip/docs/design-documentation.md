# Sema AI - Technical Design Documentation

## 1. Application Architecture

### Overview
Sema AI is a React-based web application built with TypeScript that provides multilingual chat and translation capabilities with an elegant, minimalist interface. The application follows a component-based architecture with centralized state management using Zustand.

### Tech Stack
- **Frontend Framework**: React 19.0.0 with TypeScript
- **State Management**: Zustand
- **UI Components**: Custom components with Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS
- **Icons**: Lucide React
- **Animation**: Framer Motion
- **Build Tool**: Vite

### Project Structure
```
/src
  /components         # UI components
  /store              # State management
  App.tsx             # Main application component
  main.tsx            # Application entry point
  index.css           # Global styles
```

## 2. State Management

### ChatStore (src/store/chatStore.ts)

The application uses Zustand for state management, providing a centralized store that handles all chat-related functionality.

#### State Structure
- `messages`: Array of chat messages
- `isLoading`: Boolean flag for loading states
- `activeConversationId`: Current active conversation ID

#### Actions
- `addMessage`: Adds a new message to the chat
- `updateMessage`: Updates an existing message (for edits)
- `setMessageFeedback`: Sets feedback (thumbs up/down) on messages
- `getLastUserMessage`: Retrieves the last message sent by the user
- `redoLastUserMessage`: Re-sends the last user message
- `clearMessages`: Clears all messages
- `setIsLoading`: Sets the loading state
- `setActiveConversationId`: Sets the active conversation

#### Implementation Details
The store uses a custom Message type with the following properties:
- `id`: Unique message identifier
- `content`: Message text content
- `role`: Either 'user' or 'assistant'
- `timestamp`: When the message was sent
- `feedback`: Optional feedback ('positive' or 'negative')
- `edited`: Boolean flag for edited messages

## 3. Component Breakdown

### App Component (src/App.tsx)

The App component serves as the main container for the application.

#### State
- `inputValue`: Current text in the input field
- `isTranslateMode`: Boolean toggle between chat and translate modes
- `editingMessageId`: ID of message being edited (null if none)
- `isSidebarOpen`: Controls sidebar visibility
- `showSettings`: Controls settings visibility

#### Key Functions
- `handleSubmit`: Processes form submission for sending messages
- `handleEditMessage`: Handles message editing
- `handleRedoMessage`: Re-sends the last user message
- `toggleMode`: Switches between chat and translate modes
- `handleNewChat`: Starts a new chat session

#### UI Structure
1. Sidebar (collapsible)
2. Main content area:
   - Header with app title and sign-in
   - Chat container showing messages
   - Input section with text area and action buttons

#### Lifecycle
- On mount: Loads Google fonts, adds initial welcome message
- Sets up drag and drop functionality for file uploads

### ChatContainer Component (src/components/ChatContainer.tsx)

Responsible for rendering the message thread with user and AI interactions.

#### Props
- `messages`: Array of messages to display
- `isLoading`: Boolean indicating if a response is loading
- `onEditMessage`: Callback for editing messages
- `onRedoMessage`: Callback for redoing the last message

#### Key Features
- Auto-scrolls to the latest message
- Displays different styling for user vs AI messages
- Provides message actions (copy, edit, feedback)
- Shows typing animation during loading states
- Displays welcome screen when no messages exist

#### UI Elements
- Message bubbles with different styling based on sender
- Action buttons for message interactions
- Copy feedback with animation
- Loading indicators
- Empty state welcome screen

### Sidebar Component (src/components/Sidebar.tsx)

Provides navigation and conversation management.

#### Props
- `isOpen`: Boolean controlling sidebar expanded/collapsed state
- `onToggle`: Callback to toggle sidebar state
- `onNewChat`: Callback to start a new conversation

#### UI Elements
- Toggle button to expand/collapse
- New chat button
- Recent conversations list
- Settings and help options
- Dark mode toggle

#### States
- Collapsed: Shows only icons
- Expanded: Shows full sidebar with labels and conversation history

### FileUploadButton Component (src/components/FileUploadButton.tsx)

Handles file selection and upload functionality.

#### Props
- `onFileUpload`: Callback function that receives the selected file

#### Implementation
- Uses a hidden file input
- Triggered by a visible button with a plus icon
- Supports various file types (documents, images)
- Provides tooltip on hover

## 4. UI/UX Design Patterns

### Color Scheme
- **Primary**: Black (#000000)
- **Primary Hover**: Dark Gray (#333333)
- **Background**: White (#ffffff)
- **Surface**: White (#ffffff)
- **Surface Hover**: Light Gray (#f0f0f0)
- **Border**: Gray (#e0e0e0)
- **Text Primary**: Black (#000000)
- **Text Secondary**: Dark Gray (#444444)
- **Text Muted**: Gray (#888888)

### Typography
- **Font Family**: Inter (Google Fonts)
- **Weights**: 400 (Regular), 500 (Medium), 600 (Semibold), 700 (Bold)

### Input Area
The input area follows a two-part vertical layout:
1. **Top**: Text input field with auto-expanding height
2. **Bottom**: Action bar with tool buttons on left, send button on right

#### Button Types
- **Action Buttons**: Square with border, 32x32px
- **Send Button**: Circular, 40x40px
- **Active State**: Black background with white icon
- **Inactive State**: Gray background with muted icon

### Message Bubbles
- **User Messages**: Light gray background (#f0f0f0), rounded corners except top-right
- **AI Messages**: White background with border, rounded corners except top-left
- **Message Actions**: Appear below messages with hover tooltips
- **Feedback**: Visual indicators for copied text and feedback actions

### Animations
- **Message Entry**: Fade and slide up
- **Loading Indicator**: Pulsing dots
- **Tooltips**: Fade in/out
- **Copy Confirmation**: Temporary popup with fade

## 5. Data Flow

### Message Sending Flow
1. User enters text in input field
2. Submit event triggered (Enter key or send button)
3. New message added to store with 'user' role
4. Loading state activated
5. Simulated AI response after delay
6. AI response added to store with 'assistant' role
7. Loading state deactivated

### Message Editing Flow
1. User clicks edit button on a message
2. Message content loaded into input field
3. EditingMessageId state updated
4. User modifies text and submits
5. Message updated in store with edited flag
6. Input cleared and editingMessageId reset

### Message Feedback Flow
1. User clicks thumbs up/down on a message
2. Feedback status stored in message object
3. UI updates to show selected feedback state
4. Clicking again on same feedback removes it

### Mode Switching Flow
1. User clicks chat/translate toggle button
2. isTranslateMode state toggled
3. Input placeholder and response handling adjusted based on mode

## 6. Implementation Guide

### Setting Up the Project
1. Create a new React + TypeScript project with Vite
2. Install dependencies: Zustand, Framer Motion, Lucide React, Radix UI, Tailwind CSS
3. Set up the project structure following the architecture

### Building the Components
1. Start with the store implementation (chatStore.ts)
2. Implement the basic App component with layout structure
3. Build the ChatContainer component for message display
4. Create the Sidebar component for navigation
5. Implement the FileUploadButton component
6. Connect all components with the store

### Styling Implementation
1. Set up Tailwind CSS configuration
2. Add custom CSS variables for theme colors
3. Implement global styles for scrollbars, animations
4. Style individual components following the UI patterns

### Testing and Refinement
1. Test message sending and receiving flow
2. Verify message editing functionality
3. Test feedback mechanisms
4. Ensure responsive layout works correctly
5. Verify animations and transitions

### Performance Considerations
1. Use React.memo for pure components
2. Implement virtualization for long message lists
3. Optimize re-renders with proper key usage
4. Use useCallback for event handlers passed to child components

This documentation provides a comprehensive guide to understand and rebuild the Sema AI application, covering all essential components, state management, UI patterns, and implementation details.
