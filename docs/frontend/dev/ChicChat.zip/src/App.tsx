import { useState, useEffect, useRef } from 'react';
import './index.css';
import Sidebar from './components/Sidebar';
import ChatContainer from './components/ChatContainer';
import FileUploadButton from './components/FileUploadButton';
import { ArrowUp, Languages, Loader, MessageCircle } from 'lucide-react';

// Custom slider icon component
const SliderIcon = () => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M3 6.5H15" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    <rect x="7" y="5.5" width="4" height="2" rx="1" fill="currentColor"/>
    <path d="M3 11.5H15" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    <rect x="7" y="10.5" width="4" height="2" rx="1" fill="currentColor"/>
  </svg>
);
import { useChatStore } from './store/chatStore';
import type { Message } from './store/chatStore';

// Main app component
export function App() {
  const [inputValue, setInputValue] = useState('');
  const [isTranslateMode, setIsTranslateMode] = useState(false);
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const { messages, addMessage, updateMessage, isLoading, setIsLoading, clearMessages } = useChatStore();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
    
    // Add initial welcome message if no messages
    if (messages.length === 0) {
      setTimeout(() => {
        addMessage({
          content: "🌍 Experience AI in your native language",
          role: 'assistant'
        });
      }, 500);
    }
    
    // Set up drag and drop for input area
    const dragArea = document.getElementById('dragDropArea');
    if (dragArea) {
      const handleDragOver = (e: DragEvent) => {
        e.preventDefault();
        dragArea.classList.add('drag-active');
      };
      
      const handleDragLeave = () => {
        dragArea.classList.remove('drag-active');
      };
      
      const handleDrop = (e: DragEvent) => {
        e.preventDefault();
        dragArea.classList.remove('drag-active');
        
        if (e.dataTransfer?.files.length) {
          console.log('File dropped:', e.dataTransfer.files[0].name);
          // Handle file drop (same as file upload)
        }
      };
      
      dragArea.addEventListener('dragover', handleDragOver);
      dragArea.addEventListener('dragleave', handleDragLeave);
      dragArea.addEventListener('drop', handleDrop);
      
      return () => {
        document.head.removeChild(link);
        dragArea.removeEventListener('dragover', handleDragOver);
        dragArea.removeEventListener('dragleave', handleDragLeave);
        dragArea.removeEventListener('drop', handleDrop);
      };
    }
    
    return () => {
      document.head.removeChild(link);
    };
  }, [addMessage, messages.length]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;
    
    if (editingMessageId) {
      // Update existing message
      updateMessage(editingMessageId, {
        content: inputValue
      });
      setEditingMessageId(null);
    } else {
      // Add new user message
      addMessage({
        content: inputValue,
        role: 'user'
      });
      
      // Set loading state and simulate AI response
      setIsLoading(true);
      
      setTimeout(() => {
        let responseContent = "I'm here to help with translations and multilingual conversations. What language would you like to use today?";
        
        if (isTranslateMode) {
          responseContent = "Here's your translation: [Translation would appear here]";
        }
        
        addMessage({
          content: responseContent,
          role: 'assistant'
        });
        
        setIsLoading(false);
      }, 2000);
    }
    
    setInputValue('');
    
    // Focus the input after sending
    setTimeout(() => {
      inputRef.current?.focus();
    }, 0);
  };
  
  const handleEditMessage = (id: string, content: string) => {
    setEditingMessageId(id);
    setInputValue(content);
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const handleRedoMessage = () => {
    if (isLoading) return;
    
    const redoMessage = useChatStore.getState().redoLastUserMessage();
    if (redoMessage) {
      // Set loading state and simulate AI response
      setIsLoading(true);
      
      setTimeout(() => {
        let responseContent = "I've reconsidered your question. Here's a different perspective on your request.";
        
        if (isTranslateMode) {
          responseContent = "Here's an alternative translation: [Alternative translation would appear here]";
        }
        
        addMessage({
          content: responseContent,
          role: 'assistant'
        });
        
        setIsLoading(false);
      }, 2000);
    }
  };

  const toggleMode = () => {
    setIsTranslateMode(!isTranslateMode);
  };

  const handleNewChat = () => {
    clearMessages();
    setInputValue('');
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  return (
    <div className="fixed inset-0 flex bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      {/* Sidebar */}
      <Sidebar isOpen={isSidebarOpen} onToggle={() => setIsSidebarOpen(!isSidebarOpen)} onNewChat={handleNewChat} />
      
      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Header */}
        <header className="h-16 flex items-center justify-between px-6 bg-white">
          <div className="flex items-center gap-2">
            <span className="text-[#000000] font-semibold text-lg">Sema AI</span>
          </div>
          <div className="flex items-center gap-4">
            <a href="#" className="text-[#444444] hover:text-[#000000]">About Sema</a>
            <button className="px-4 py-2 rounded-full bg-[#000000] text-white text-sm font-medium">
              Sign In
            </button>
          </div>
        </header>
        
        {/* Chat Container */}
        <ChatContainer 
          messages={messages} 
          isLoading={isLoading} 
          onEditMessage={handleEditMessage}
          onRedoMessage={handleRedoMessage}
        />
        
        {/* Input Section */}
        <div className="flex justify-center pb-6">
          <div className="w-full max-w-2xl px-4">
            
            <div className="input-container" id="dragDropArea">
              <form onSubmit={handleSubmit} className="flex flex-col gap-3">
                {/* Input Field - Top */}
                <div className="input-field-wrapper">
                  <textarea
                    ref={inputRef}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder={editingMessageId ? "Edit your message..." : isTranslateMode ? "Type text to translate..." : "Reply to Claude..."}
                    className="input-field"
                    rows={1}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        if (inputValue.trim() && !isLoading) {
                          handleSubmit(e);
                        }
                      }
                    }}
                    style={{ 
                      height: Math.min(Math.max(56, inputValue.split('\n').length * 24 + 32), 300) + 'px' 
                    }}
                  />
                </div>
                
                {/* Button Row - Bottom */}
                <div className="button-row">
                  {/* Left Side Button Group */}
                  <div className="left-buttons">
                    {/* Plus Icon */}
                    <FileUploadButton 
                      onFileUpload={(file) => {
                        console.log('File uploaded:', file.name);
                        // Here you would handle the file upload
                      }} 
                    />
                    
                    {/* Slider/Control Icon */}
                    <button 
                      type="button" 
                      className="action-button relative"
                      aria-label="Settings"
                      onClick={() => setShowSettings(!showSettings)}
                      onMouseEnter={(e) => {
                        const tooltip = document.createElement('div');
                        tooltip.className = 'tooltip';
                        tooltip.textContent = 'Settings';
                        e.currentTarget.appendChild(tooltip);
                      }}
                      onMouseLeave={(e) => {
                        const tooltip = e.currentTarget.querySelector('.tooltip');
                        if (tooltip) e.currentTarget.removeChild(tooltip);
                      }}
                    >
                      <SliderIcon />
                    </button>
                    
                    {/* Chat Icon */}
                    <button 
                      type="button"
                      onClick={toggleMode}
                      className={`action-button ${!isTranslateMode ? 'active' : ''} relative`}
                      aria-label="Chat"
                      onMouseEnter={(e) => {
                        const tooltip = document.createElement('div');
                        tooltip.className = 'tooltip';
                        tooltip.textContent = 'Chat Mode';
                        e.currentTarget.appendChild(tooltip);
                      }}
                      onMouseLeave={(e) => {
                        const tooltip = e.currentTarget.querySelector('.tooltip');
                        if (tooltip) e.currentTarget.removeChild(tooltip);
                      }}
                    >
                      <MessageCircle size={18} />
                    </button>
                    
                    {/* Translate Icon */}
                    <button 
                      type="button"
                      onClick={toggleMode}
                      className={`action-button ${isTranslateMode ? 'active' : ''} relative`}
                      aria-label="Translate"
                      onMouseEnter={(e) => {
                        const tooltip = document.createElement('div');
                        tooltip.className = 'tooltip';
                        tooltip.textContent = 'Translation Mode';
                        e.currentTarget.appendChild(tooltip);
                      }}
                      onMouseLeave={(e) => {
                        const tooltip = e.currentTarget.querySelector('.tooltip');
                        if (tooltip) e.currentTarget.removeChild(tooltip);
                      }}
                    >
                      <Languages size={18} />
                    </button>
                  </div>
                  
                  {/* Right Side - Send Button Only */}
                  <button 
                    type="submit" 
                    className={`send-button-circular ${!inputValue.trim() || (isLoading && !editingMessageId) ? 'empty' : 'filled'}`}
                    disabled={!inputValue.trim() || (isLoading && !editingMessageId)}
                  >
                    {isLoading ? (
                      <div className="spinner"></div>
                    ) : (
                      <ArrowUp size={18} />
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
