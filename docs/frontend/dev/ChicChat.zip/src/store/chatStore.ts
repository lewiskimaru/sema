import { create } from 'zustand';

// Define types
export type Message = {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  feedback?: 'positive' | 'negative';
  edited?: boolean;
};

export type ChatState = {
  messages: Message[];
  addMessage: (message: Omit<Message, 'id' | 'timestamp'>) => void;
  updateMessage: (id: string, updates: Partial<Omit<Message, 'id' | 'timestamp'>>) => void;
  setMessageFeedback: (id: string, feedback: 'positive' | 'negative' | undefined) => void;
  getLastUserMessage: () => Message | undefined;
  redoLastUserMessage: () => Message | undefined;
  clearMessages: () => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  activeConversationId: string | null;
  setActiveConversationId: (id: string | null) => void;
};

// Create store
export const useChatStore = create<ChatState>((set, get) => ({
  messages: [],
  isLoading: false,
  activeConversationId: null,
  addMessage: (message) => 
    set((state) => ({ 
      messages: [...state.messages, { 
        ...message, 
        id: Math.random().toString(36).substring(2, 9),
        timestamp: new Date() 
      }]
    })),
  updateMessage: (id, updates) =>
    set((state) => ({
      messages: state.messages.map(message => 
        message.id === id ? { ...message, ...updates, edited: true } : message
      )
    })),
  updateMessage: (id, updates) =>
    set((state) => ({
      messages: state.messages.map(message => 
        message.id === id ? { ...message, ...updates, edited: true } : message
      )
    })),
  setMessageFeedback: (id, feedback) =>
    set((state) => ({
      messages: state.messages.map(message => 
        message.id === id ? { ...message, feedback } : message
      )
    })),
  getLastUserMessage: () => {
    const messages = get().messages;
    return [...messages].reverse().find(m => m.role === 'user');
  },
  redoLastUserMessage: () => {
    const lastUserMessage = get().getLastUserMessage();
    if (lastUserMessage) {
      // Create a new copy to trigger re-sending
      const newMessage = {
        content: lastUserMessage.content,
        role: 'user' as const
      };
      get().addMessage(newMessage);
      return lastUserMessage;
    }
    return undefined;
  },
  clearMessages: () => set({ messages: [] }),
  setIsLoading: (loading) => set({ isLoading: loading }),
  setActiveConversationId: (id) => set({ activeConversationId: id }),
}));
