import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Check, Copy, Loader, Pencil, RefreshCw, ThumbsDown, ThumbsUp } from 'lucide-react';
import type { Message } from '../store/chatStore';
import { useChatStore } from '../store/chatStore';

type ChatContainerProps = {
  messages: Message[];
  isLoading: boolean;
  onEditMessage: (id: string, content: string) => void;
  onRedoMessage: () => void;
};

const ChatContainer = ({ messages, isLoading, onEditMessage, onRedoMessage }: ChatContainerProps) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { setMessageFeedback } = useChatStore();
  const [copiedId, setCopiedId] = useState<string | null>(null);
  
  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Reset copied state after 2 seconds
  useEffect(() => {
    if (copiedId) {
      const timeout = setTimeout(() => {
        setCopiedId(null);
      }, 2000);
      return () => clearTimeout(timeout);
    }
  }, [copiedId]);

  // Copy text to clipboard
  const copyToClipboard = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      // Reset copied state after 2 seconds
      setTimeout(() => {
        setCopiedId(null);
      }, 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  // If no messages, show welcome screen
  if (messages.length === 0) {
    return (
      <div className="flex-1 overflow-y-auto flex flex-col items-center justify-center p-4 bg-white">
        <div className="w-full max-w-3xl">
          <div className="text-center">
            <div className="mb-6">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#000000]">
                <span className="text-white text-2xl font-bold">S</span>
              </div>
            </div>
            <h1 className="text-2xl font-bold text-[#000000] mb-2">Welcome to Sema AI</h1>
            <p className="text-[#444444] mb-6">Experience AI in your native language</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-w-lg mx-auto">
              <button className="bg-white border border-[#e2e8f0] rounded-lg p-4 text-left hover:bg-[#f1f5f9] transition-colors">
                <div className="font-medium text-[#0f172a] mb-1">Translation</div>
                <div className="text-sm text-[#475569]">Translate text between 200+ languages</div>
              </button>
              <button className="bg-white border border-[#e2e8f0] rounded-lg p-4 text-left hover:bg-[#f1f5f9] transition-colors">
                <div className="font-medium text-[#0f172a] mb-1">Chat</div>
                <div className="text-sm text-[#475569]">Chat with AI in your native language</div>
              </button>
              <button className="bg-white border border-[#e2e8f0] rounded-lg p-4 text-left hover:bg-[#f1f5f9] transition-colors">
                <div className="font-medium text-[#0f172a] mb-1">Document Translation</div>
                <div className="text-sm text-[#475569]">Upload and translate documents</div>
              </button>
              <button className="bg-white border border-[#e2e8f0] rounded-lg p-4 text-left hover:bg-[#f1f5f9] transition-colors">
                <div className="font-medium text-[#0f172a] mb-1">Language Learning</div>
                <div className="text-sm text-[#475569]">Practice and improve language skills</div>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto py-6 bg-white">
      <div className="w-full max-w-2xl mx-auto px-4">
        {messages.map((message) => (
          <motion.div
            key={message.id}
            className={`mb-6 ${message.role === 'user' ? 'flex justify-end' : ''}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className={`max-w-[85%] ${message.role === 'user' ? 'ml-auto' : ''}`}>
              {message.role === 'assistant' && (
                <div className="flex items-start gap-3">
                  <div className="w-full">
                    <div className="bg-white rounded-2xl rounded-tl-none px-4 py-3 border border-[#e0e0e0] relative">
                      <div className="text-[#000000] leading-relaxed whitespace-pre-wrap">
                        {message.content}
                        {message.edited && (
                          <span className="text-xs text-[#888888] ml-2">(edited)</span>
                        )}
                      </div>
                    </div>
                    <div className="mt-1 ml-2 flex items-center gap-2">
                      <button 
                        className="p-1 text-[#888888] hover:text-[#000000] rounded relative" 
                        onClick={onRedoMessage}
                        onMouseEnter={(e) => {
                          const tooltip = document.createElement('div');
                          tooltip.className = 'tooltip';
                          tooltip.textContent = 'Redo message';
                          e.currentTarget.appendChild(tooltip);
                        }}
                        onMouseLeave={(e) => {
                          const tooltip = e.currentTarget.querySelector('.tooltip');
                          if (tooltip) e.currentTarget.removeChild(tooltip);
                        }}
                      >
                        <RefreshCw size={16} />
                      </button>
                      <button 
                        className="p-1 text-[#888888] hover:text-[#000000] rounded relative" 
                        onClick={() => copyToClipboard(message.content, message.id)}
                        onMouseEnter={(e) => {
                          if (copiedId !== message.id) {
                            const tooltip = document.createElement('div');
                            tooltip.className = 'tooltip';
                            tooltip.textContent = 'Copy message';
                            e.currentTarget.appendChild(tooltip);
                          }
                        }}
                        onMouseLeave={(e) => {
                          const tooltip = e.currentTarget.querySelector('.tooltip');
                          if (tooltip) e.currentTarget.removeChild(tooltip);
                        }}
                      >
                        {copiedId === message.id ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
                        {copiedId === message.id && (
                          <motion.div 
                            className="absolute text-xs bg-[#000000] text-white px-2 py-1 rounded -top-8 left-1/2 transform -translate-x-1/2"
                            initial={{ opacity: 0, y: 5 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0 }}
                          >
                            Copied!
                          </motion.div>
                        )}
                      </button>
                      <button 
                        className={`p-1 rounded relative ${message.feedback === 'positive' ? 'text-[#000000]' : 'text-[#888888] hover:text-[#000000]'}`}
                        onClick={() => setMessageFeedback(message.id, message.feedback === 'positive' ? undefined : 'positive')}
                        onMouseEnter={(e) => {
                          const tooltip = document.createElement('div');
                          tooltip.className = 'tooltip';
                          tooltip.textContent = 'Thumbs up';
                          e.currentTarget.appendChild(tooltip);
                        }}
                        onMouseLeave={(e) => {
                          const tooltip = e.currentTarget.querySelector('.tooltip');
                          if (tooltip) e.currentTarget.removeChild(tooltip);
                        }}
                      >
                        <ThumbsUp size={16} />
                      </button>
                      <button 
                        className={`p-1 rounded relative ${message.feedback === 'negative' ? 'text-[#000000]' : 'text-[#888888] hover:text-[#000000]'}`}
                        onClick={() => setMessageFeedback(message.id, message.feedback === 'negative' ? undefined : 'negative')}
                        onMouseEnter={(e) => {
                          const tooltip = document.createElement('div');
                          tooltip.className = 'tooltip';
                          tooltip.textContent = 'Thumbs down';
                          e.currentTarget.appendChild(tooltip);
                        }}
                        onMouseLeave={(e) => {
                          const tooltip = e.currentTarget.querySelector('.tooltip');
                          if (tooltip) e.currentTarget.removeChild(tooltip);
                        }}
                      >
                        <ThumbsDown size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              )}
              
              {message.role === 'user' && (
                <div className="flex flex-col items-end">
                  <div className="bg-[#f0f0f0] rounded-2xl rounded-tr-none px-4 py-3 border border-[#e0e0e0]">
                    <div className="text-[#000000] leading-relaxed whitespace-pre-wrap">
                      {message.content}
                      {message.edited && (
                        <span className="text-xs text-[#888888] ml-2">(edited)</span>
                      )}
                    </div>
                  </div>
                  <div className="mt-1 mr-2 flex items-center gap-2">
                    <button 
                      className="p-1 text-[#888888] hover:text-[#000000] rounded relative" 
                      onClick={() => onEditMessage(message.id, message.content)}
                      onMouseEnter={(e) => {
                        const tooltip = document.createElement('div');
                        tooltip.className = 'tooltip';
                        tooltip.textContent = 'Edit message';
                        e.currentTarget.appendChild(tooltip);
                      }}
                      onMouseLeave={(e) => {
                        const tooltip = e.currentTarget.querySelector('.tooltip');
                        if (tooltip) e.currentTarget.removeChild(tooltip);
                      }}
                    >
                      <Pencil size={16} />
                    </button>
                    <button 
                      className="p-1 text-[#888888] hover:text-[#000000] rounded relative" 
                      onClick={() => copyToClipboard(message.content, message.id)}
                      onMouseEnter={(e) => {
                        if (copiedId !== message.id) {
                          const tooltip = document.createElement('div');
                          tooltip.className = 'tooltip';
                          tooltip.textContent = 'Copy message';
                          e.currentTarget.appendChild(tooltip);
                        }
                      }}
                      onMouseLeave={(e) => {
                        const tooltip = e.currentTarget.querySelector('.tooltip');
                        if (tooltip) e.currentTarget.removeChild(tooltip);
                      }}
                    >
                      {copiedId === message.id ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
                      {copiedId === message.id && (
                        <motion.div 
                          className="absolute text-xs bg-[#000000] text-white px-2 py-1 rounded -top-8 left-1/2 transform -translate-x-1/2"
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0 }}
                        >
                          Copied!
                        </motion.div>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        ))}
        
        {/* Loading indicator */}
        {isLoading && (
          <motion.div 
            className="flex items-start gap-3 mb-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <div className="bg-white rounded-2xl rounded-tl-none px-4 py-3 border border-[#e0e0e0]">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-[#888888] animate-pulse"></div>
                <div className="w-2 h-2 rounded-full bg-[#888888] animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 rounded-full bg-[#888888] animate-pulse" style={{ animationDelay: '0.4s' }}></div>
              </div>
            </div>
          </motion.div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
};

export default ChatContainer;
