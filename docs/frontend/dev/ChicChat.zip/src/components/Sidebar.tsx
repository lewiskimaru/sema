import React from 'react';
import { CircleHelp, LayoutTemplate, MessageCircle, MoonStar, Plus, Settings } from 'lucide-react';
import { motion } from 'framer-motion';

type SidebarProps = {
  isOpen: boolean;
  onToggle: () => void;
  onNewChat: () => void;
};

// Import the chat store
import { useChatStore } from '../store/chatStore';

const Sidebar = ({ isOpen, onToggle, onNewChat }: SidebarProps) => {
  // List of conversation items (would be dynamic in a real app)
  const conversations = [
    { id: 1, title: "Translation project", date: "Today" },
    { id: 2, title: "Spanish learning chat", date: "Yesterday" },
    { id: 3, title: "Document translation", date: "May 25" },
  ];

  return (
    <aside 
      className={`h-full bg-white border-r border-[#e0e0e0] transition-all duration-300 ${isOpen ? 'w-64' : 'w-16'}`}
    >
      <div className="flex flex-col h-full">
        {/* Sidebar Header */}
        <div className="p-4 flex flex-col gap-4">
          <button 
            onClick={onToggle} 
            className="sidebar-toggle w-8 h-8 rounded-lg flex items-center justify-center transition-colors"
            aria-label="Toggle sidebar"
            title="Toggle sidebar"
          >
            <LayoutTemplate size={20} />
          </button>
          
          <button 
            onClick={onNewChat}
            className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-[#f1f5f9] transition-colors"
            aria-label="New chat"
            title="New chat"
          >
            <Plus size={20} className="text-[#475569]" />
          </button>
          
          <button 
            className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-[#f1f5f9] transition-colors"
            aria-label="Chat history"
            title="Chat history"
          >
            <MessageCircle size={20} className="text-[#475569]" />
          </button>
        </div>
        
        {/* Expanded sidebar content - only visible when isOpen is true */}
        {isOpen && (
          <motion.div 
            className="flex flex-col flex-1"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.2 }}
          >
            <div className="flex-1 overflow-y-auto p-4">
              <div className="mb-4">
                <button 
                  onClick={onNewChat}
                  className="w-full flex items-center gap-2 py-2 px-3 rounded-lg bg-[#f1f5f9] text-[#0f172a] hover:bg-[#e2e8f0] transition-colors"
                >
                  <Plus size={16} />
                  <span>New chat</span>
                </button>
              </div>
              
              <div>
                <div className="text-[#475569] text-sm font-medium mb-2">Recent conversations</div>
                <ul className="space-y-1">
                  {conversations.map((convo) => (
                    <li key={convo.id}>
                      <button className="w-full text-left py-2 px-3 rounded-lg hover:bg-[#f1f5f9] text-[#0f172a] flex justify-between items-center group transition-colors">
                        <span className="truncate">{convo.title}</span>
                        <span className="text-xs text-[#94a3b8] opacity-0 group-hover:opacity-100 transition-opacity">{convo.date}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            
            <div className="border-t border-[#e2e8f0] p-4">
              <div className="flex flex-col gap-1">
                <button className="flex items-center gap-2 py-2 px-3 rounded-lg hover:bg-[#f1f5f9] text-[#0f172a] transition-colors">
                  <Settings size={16} />
                  <span>Settings</span>
                </button>
                <button className="flex items-center gap-2 py-2 px-3 rounded-lg hover:bg-[#f1f5f9] text-[#0f172a] transition-colors">
                  <CircleHelp size={16} />
                  <span>Help & FAQ</span>
                </button>
                <button className="flex items-center gap-2 py-2 px-3 rounded-lg hover:bg-[#f1f5f9] text-[#0f172a] transition-colors">
                  <MoonStar size={16} />
                  <span>Dark mode</span>
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;
